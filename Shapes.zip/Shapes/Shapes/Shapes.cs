﻿// See https://aka.ms/new-console-template for more information
namespace Shapes
{
    /// <summary>
    /// Bank account demo class.
    /// </summary>
    public class Shapes
    {
        private int shapeOption;
        private double val;
        private double area;
        // private Shapes() { }

        public Shapes(int op, double sqSide)
        {
            shapeOption = op;
            val = sqSide;
        }

        public int ShapeOption
        {
            get { return shapeOption; }
            set { shapeOption = value; }
        }

        public double Side
        {
            get { return val; }
            set { val = value; }
        }
        public double Area
        {
            get { return area; }
            set { area = value; }
        }
        public void Menu()
        {
            try
            {
                //Console.Clear();

                if (ShapeOption < 1 || ShapeOption > 4)
                {
                    Console.WriteLine("Invalid option, Please enter correct option.");
                    Console.ReadKey();
                }
                else
                {
                    switch (ShapeOption)
                    {
                        case 1:
                            Triangle();
                            break;
                        case 2:
                            Square();
                            break;
                        case 3:
                            Rectangle();
                            break;
                        case 4:
                            Circle();
                            break;

                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.InnerException);
                Console.Read();
            }
        }

        private void Triangle()
        {
            try
            {
                Console.Clear();
                Console.WriteLine("Thank you for choosing Triangle");
                Console.WriteLine("");
                Console.WriteLine("Please enter Height of Triangle");
                double h = double.Parse(Console.ReadLine());
                Console.WriteLine("Please enter Base of Triangle");
                double b = double.Parse(Console.ReadLine());


                Console.WriteLine("Area of this Triangle is:{0}", Math.Round((h * b) / 2, 2));

                Console.ReadKey();
            }
            catch (ArgumentOutOfRangeException ex)
            {
                Console.WriteLine("Dimensions which you have entered exceeds the limits, please enter valid  value");
                Console.Read();
                Triangle();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Dimensions which you have entered is not in expected format. Please enter valid value.");
                Console.Read();
                Triangle();
            }
        }
        private void Square()
        {
            try
            {
                Console.WriteLine("Thank you for choosing Square");
                Console.WriteLine("");


                Console.WriteLine("Please enter side of Square");
                if (Side == 0)
                    Side = double.Parse(Console.ReadLine());

                Area = Math.Round(Side * Side, 2);
                Console.WriteLine("Area of this Square is:{0}", Area);

            }
            catch (ArgumentOutOfRangeException ex)
            {
                Console.WriteLine("Dimensions which you have entered exceeds the limits, please enter valid  value");
                Console.Read();
                Square();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Dimensions which you have entered is not in expected format. Please enter valid value.");
                Console.Read();
                Square();
            }
        }
        private void Rectangle()
        {
            try
            {
                Console.Clear();
                Console.WriteLine("Thank you for choosing Rectangle");
                Console.WriteLine("");
                Console.WriteLine("Please enter Length of Rectangle");
                double l = double.Parse(Console.ReadLine());
                Console.WriteLine("Please enter Width of Rectangle");
                double w = double.Parse(Console.ReadLine());


                Console.WriteLine("Area of this Rectangle is:{0}", Math.Round(l * w, 2));
                Console.ReadKey();
            }
            catch (ArgumentOutOfRangeException ex)
            {
                Console.WriteLine("Dimensions which you have entered exceeds the limits, please enter valid  value");
                Console.Read();
                Rectangle();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Dimensions which you have entered is not in expected format. Please enter valid value.");
                Console.Read();
                Rectangle();
            }
        }
        private void Circle()
        {
            try
            {
                Console.Clear();
                Console.WriteLine("Thank you for choosing Circle");
                Console.WriteLine("");
                Console.WriteLine("Please enter Radius of Circle");
                double r = double.Parse(Console.ReadLine());


                Console.WriteLine("Area of this Circle is:{0}", Math.Round(Math.PI * r * r, 2));
                Console.ReadKey();
            }
            catch (ArgumentOutOfRangeException ex)
            {
                Console.WriteLine("Dimensions which you have entered exceeds the limits, please enter valid  value");
                Console.Read();
                Circle();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Dimensions which you have entered is not in expected format. Please enter valid value.");
                Console.Read();
                Circle();
            }
        }

        public static void Main()
        {
            Console.WriteLine("Please select any shape from below options");
            Console.WriteLine("");
            Console.WriteLine("1. Triangle");
            Console.WriteLine("2. Square");
            Console.WriteLine("3. Rectangle");
            Console.WriteLine("4. Circle");

            var selectedOption = Console.ReadLine();
            if (int.TryParse(selectedOption, out int option))
            {
                Shapes ba = new Shapes(option, 0);
                ba.Menu();
            }

            else
            {
                Console.WriteLine("Please enter correct option as Integer");
                Console.ReadLine();
            }

        }
    }
}
