using Microsoft.VisualStudio.TestTools.UnitTesting;
using Shapes;

namespace ShapeTest
{

    [TestClass]
    public class ShapesTest
    {
        [TestMethod]
        public void Calculate_Area_Valid_Data()
        {
            // Arrange
            int option = 2;
            double sideOFRectangle = 10;

            Shapes.Shapes sp = new Shapes.Shapes(option,sideOFRectangle);

            // Act
            sp.Menu();

            // Assert
            double area = sp.Area;
            Assert.AreEqual(100, area);
        }

        //[TestMethod]
        //public void CalculateArea_InvalidData()
        //{
        //    // Arrange
        //    int option = 2;
        //    double sideOFRectangle = 1018838290033111113.393388;

        //    Shapes.Shapes sp = new Shapes.Shapes(option);

        //    // Act
        //    sp.Menu();

        //    // Assert
        //    double area = sp.Area;
        //    Assert.Equals(100, area);
        //}
    }

}
